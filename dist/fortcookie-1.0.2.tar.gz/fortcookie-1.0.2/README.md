Rafael Stoffalette João
rafaelstojoao@gmail.com

<br><br>
This is a simple implementation of a python package. 



If you wanna get lucky today creck() your cookie and read a good feelings message.

Good lucky!!!
<br><br>
find files on https://github.com/rafaelstojoao/fortcookie
<br>
find this package on https://pypi.org/project/fortcookie/




__________________________________________________
INSTRUCTIONS....


install with pip install fortcookie


import pandas as pd<br>
import random<br>
from fortcookie import FortumeCookie<br>
<br><br>
cookie = FortuneCookie()<br>
cookie.creck()<br>