
This is a simple implementation of a python package. 



If you wanna get lucky today creck() your cookie and read a good feelings message.

Good lucky!!!

find files on https://github.com/rafaelstojoao/fortcookie
find this package on https://pypi.org/project/fortcookie/




__________________________________________________
INSTRUCTIONS....


install with pip install fortcookie



from fortcookie import FortumeCookie
import pandas as pd
import random

cookie = FortuneCookie()
cookie.creck()